            const eyesContainer = document.getElementById('eyesContainer');
            const leftEye = document.getElementById('leftEye');
            const rightEye = document.getElementById('rightEye');
            const leftPupil = leftEye.querySelector('.pupil');
            const rightPupil = rightEye.querySelector('.pupil');

            let prevX = 0;
            let prevY = 0;

            function moveEyes() {
                const containerWidth = leftEye.offsetWidth + rightEye.offsetWidth + parseInt(getComputedStyle(rightEye).left);
                const containerHeight = leftEye.offsetHeight;

                const maxX = window.innerWidth - containerWidth;
                const maxY = window.innerHeight - containerHeight;

                const x = Math.random() * maxX;
                const y = Math.random() * maxY;

                eyesContainer.style.transform = `translate(${x}px, ${y}px)`;

                // Move pupils
                const dx = x - prevX;
                const dy = y - prevY;
                const maxPupilMove = 20; // Maximum pixel movement for pupils

                const pupilX = Math.max(-maxPupilMove, Math.min(maxPupilMove, dx / 5));
                const pupilY = Math.max(-maxPupilMove, Math.min(maxPupilMove, dy / 5));

                leftPupil.style.transform = `translate(calc(-50% + ${pupilX}px), calc(-50% + ${pupilY}px))`;
                rightPupil.style.transform = `translate(calc(-50% + ${pupilX}px), calc(-50% + ${pupilY}px))`;

                prevX = x;
                prevY = y;
            }

            // Initial position
            moveEyes();

            // Move eyes every 3 seconds
            setInterval(moveEyes, 3000);

            // Make it responsive
            window.addEventListener('resize', moveEyes);
