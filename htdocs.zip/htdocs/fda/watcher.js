function monitorActivity(duration = 5000) {
    const states = {
        ACTIVE: 'active',
        INACTIVE: 'inactive',
        COOLDOWN: 'cooldown',
        WAITING: 'waiting'
    };

    let currentState = states.INACTIVE;
    let timer;
    let cooldownTimer;
    let activityDuringCooldown = false;

    function setState(newState) {
        if (newState === currentState) return;

        currentState = newState;
        clearTimeout(timer);
        clearTimeout(cooldownTimer);

        switch (newState) {
            case states.ACTIVE:
                //console.log("Activity detected");
                document.getElementById('main').hidden = false;
                document.getElementById('eyesContainer').hidden = true;
                break;
            case states.INACTIVE:
                //console.log("No activity");
                document.getElementById('main').hidden = true;
                document.getElementById('eyesContainer').hidden = false;
                break;
            case states.COOLDOWN:
                //console.log("Cooldown");
                cooldownTimer = setTimeout(() => {
                    if (activityDuringCooldown) {
                        setState(states.ACTIVE);
                        activityDuringCooldown = false;
                    } else {
                        setState(states.INACTIVE);
                    }
                }, duration);
                break;
            case states.WAITING:
                document.getElementById('main').hidden = false;
                document.getElementById('eyesContainer').hidden = true;
                //console.log("Waiting for activity");
                break;
        }
    }

    function handleActivity() {
        if (currentState === states.COOLDOWN) {
            activityDuringCooldown = true;
        } else if (currentState === states.INACTIVE) {
            setState(states.WAITING);
            setTimeout(() => {
                if (currentState === states.WAITING) {
                    setState(states.ACTIVE);
                    timer = setTimeout(() => setState(states.COOLDOWN), duration * 3);
                }
            }, duration / 2); // Adjust this delay as needed
        } else if (currentState === states.ACTIVE) {
            clearTimeout(timer); // Reset the cooldown timer
            timer = setTimeout(() => setState(states.COOLDOWN), duration * 3);
        }
    }

    // Helper function to check if a mutation is likely an animation
    function isLikelyAnimation(mutation) {
        if (mutation.type === 'attributes') {
            const changedAttr = mutation.attributeName;
            return changedAttr === 'style' || changedAttr === 'class' || changedAttr.startsWith('data-') || changedAttr === 'hidden';
        }
        return false;
    }

    // Monitor DOM changes
    const observer = new MutationObserver((mutations) => {
        const significantChange = mutations.some(mutation => !isLikelyAnimation(mutation));
        if (significantChange) {
            handleActivity();
        }
    });

    observer.observe(document.body, {
        childList: true,
        attributes: true,
        characterData: true,
        subtree: true,
        attributeOldValue: true
    });

    // Monitor mouse movement
    document.addEventListener('mousemove', handleActivity);

    // Initial setup
    setState(states.INACTIVE);

    // Cleanup function
    return function stopMonitoring() {
        observer.disconnect();
        document.removeEventListener('mousemove', handleActivity);
        clearTimeout(timer);
        clearTimeout(cooldownTimer);
        //console.log("Monitoring stopped");
    };
}

// Start monitoring
const stopMonitoring = monitorActivity();

// To stop monitoring later (if needed):
// stopMonitoring();
