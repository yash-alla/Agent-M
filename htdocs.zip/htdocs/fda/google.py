import os
import time
import google.generativeai as genai

genai.configure(api_key='AIzaSyCgueq9FGk6WiG92GsKj0hwiBE64HJJhoc')

sys_ins=''
with open('instruction.txt', 'r', encoding='utf-8') as file:
    sys_ins = file.read().replace('\n', '')
    print(f"File content: {sys_ins}")

print('hhh')
info = ''


# Create the model
generation_config = {
  "temperature": 1,
  "top_p": 0.95,
  "top_k": 64,
  "max_output_tokens": 8192,
  "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
  model_name="gemini-1.5-pro",
  generation_config=generation_config,
  system_instruction=sys_ins+info
  )

# Initialize with initial chat history
chat_history = []

chat_session = model.start_chat(history=chat_history)

# Simulate a conversation loop
while True:
    user_input = input("You: ")  # Replace with how you get user input

    # Add user input to history
    chat_history.append({
        "role": "user",
        "parts": [user_input + "\n"],
    })

    # Send user input and get model response
    response = chat_session.send_message(user_input)

    # Add model response to history
    chat_history.append({
        "role": "model",
        "parts": [response.text + "\n"],
    })

    # Print model response
    print("Model:", response.text)  # Replace with how you display the model response

    # Break loop if exit condition is met (optional)
    if user_input.lower() == "exit":
        break
