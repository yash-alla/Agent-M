const SECRET_TOKEN = "your_secret_token";
const MAX_RETRIES = 5;
const RETRY_DELAY = 6000; // 3 seconds

let retryCount = 0;
let ws;

function connectWebSocket() {
    ws = new WebSocket('ws://127.0.0.1:12345');

    ws.onopen = () => {
        console.log('Connected to WebSocket server');
        retryCount = 0; // Reset retry count on successful connection
    };

    ws.onmessage = (event) => {
        if (event.data === "AUTH_REQUIRED") {
            ws.send(SECRET_TOKEN);
        } else if (event.data === "AUTH_SUCCESS") {
            console.log('Authenticated successfully');
        } else if (event.data === "AUTH_FAILED") {
            console.error('Authentication failed');
        } else {
            document.getElementById('mic').hidden = true;
            document.getElementById('ear').hidden = true;
            document.getElementById('talk').hidden = false;
            displayMessage(event.data);
            console.log('Processed message from server:', event.data);
        }
    };

    ws.onclose = (event) => {
        console.log('WebSocket connection closed:', event.reason);
        retryConnection();
    };

    ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        ws.close(); // This will trigger onclose event
    };
}

function retryConnection() {
    if (retryCount < MAX_RETRIES) {
        retryCount++;
        console.log(`Attempting to reconnect... (Attempt ${retryCount}/${MAX_RETRIES})`);
        setTimeout(connectWebSocket, RETRY_DELAY);
    } else {
        console.error('Max retries reached. Could not connect to WebSocket server.');
    }
}

// Initial connection attempt
connectWebSocket();

// Function to manually retry connection
function manualRetry() {
    retryCount = 0; // Reset retry count
    connectWebSocket();
}

function fs(input) {
    const allowedCharsRegex = /[a-zA-Z0-9\-_{}\?\.\:\$& ]/g;
    return input.match(allowedCharsRegex).join('');
}

function splitSentences(text) {
    // Use a regular expression to split the text
    // This regex looks for .!? followed by a space or end of string
    const sentences = text.split(/[.!?](?=\s|$)/);
    
    // Trim whitespace from each sentence and remove empty strings
    return sentences
        .map(sentence => sentence.trim())
        .filter(sentence => sentence.length > 0);
}


async function displayGMessage(message) {
    const messageContainer = document.getElementById('guest');
    messageContainer.textContent = '';
    let index = 0;

    function showNextCharacter() {
        if (index < message.length) {
            messageContainer.textContent += message.charAt(index);
            index++;
            setTimeout(showNextCharacter, 5);
        }
    }
    showNextCharacter();
}


async function displayMessage(message) {
    //stopMonitoring();
    if(message != "listen^"){
    const messageContainer = document.getElementById('message');
    messageContainer.textContent = '';
    let index = 0;

    function showNextCharacter() {
        if (index < message.length) {
            messageContainer.textContent += message.charAt(index);
            index++;
            setTimeout(showNextCharacter, 5);
        }
    }
    showNextCharacter();}else{
        startButton.click();
    }
}

const startButton = document.getElementById('startButton');
const output = document.getElementById('output');

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition || window.mozSpeechRecognition || window.msSpeechRecognition;

if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => {
        document.getElementById('mic').hidden = true;
        document.getElementById('ear').hidden = false;
        document.getElementById('talk').hidden = true;
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        console.log('Recognized:', transcript);

        ws.send(transcript);
        displayGMessage(transcript);
        output.textContent = transcript;
    };

    recognition.onerror = (event) => {
        document.getElementById('mic').hidden = false;
        document.getElementById('ear').hidden = true;
        document.getElementById('talk').hidden = true;
        switch(event.error) {
            case 'no-speech':
                output.textContent = 'No speech was detected. Try again.';
                break;
            case 'audio-capture':
                output.textContent = 'No microphone was found. Ensure that a microphone is installed.';
                break;
            case 'not-allowed':
                output.textContent = 'Permission to use microphone was denied.';
                break;
            default:
                output.textContent = 'Error occurred in recognition: ' + event.error;
        }
    };

    recognition.onend = () => {
        console.log('Speech recognition service disconnected');
    };

    startButton.addEventListener('click', () => {
        document.getElementById('ear').hidden = false;
        document.getElementById('mic').hidden = true;
        document.getElementById('talk').hidden = true;
        recognition.start();
        output.textContent = 'Listening...';
    });

    document.getElementById('ear').addEventListener('click', () => {
        document.getElementById('ear').hidden = false;
        document.getElementById('mic').hidden = true;
        document.getElementById('talk').hidden = true;
        recognition.start();
        output.textContent = 'Listening...';
    });
} else {
    console.error('Speech recognition is not supported in this browser');
    // Provide alternative functionality or message to the user
}
