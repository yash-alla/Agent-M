
from groq import Groq
from simple_websocket_server import WebSocketServer, WebSocket
import threading


SECRET_TOKEN = "your_secret_token"

context = [{
                "role": "system",
                "content": "You are a motel front desk assistant. First, ask the guest to scan their ID.  After confirming the ID scan, proceed to collect the following information one by one: full name, phone number, check-in date, check-out date, number of people staying in the room, any pets, and preferred payment type (cash or credit). Once all information has been gathered, return a response in JSON format, starting with the keyword 'result' for the program to detect. and for your information today is 28th tuesday may 2024"
            }]


class AuthWebSocket(WebSocket):
    def handle(self):
        if not hasattr(self, 'authenticated'):
            self.authenticated = False

        if self.data == SECRET_TOKEN:
            self.authenticated = True
            self.send_message("AUTH_SUCCESS")
            print(f"Client {self.address} authenticated successfully")
        elif self.authenticated:
            print(f"Received message from client {self.address}: {self.data}")
            processed_message = self.data # Example processing
            
            client = Groq(api_key="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")
            context.append({
                "role": "user",
                "content": self.data
            })
            completion = client.chat.completions.create(
                model="llama3-8b-8192",
                messages=context,
                temperature=1,
                top_p=1,
                stream=True,
                stop=None,
            )
            # print (completion)
            result = ""
            for chunk in completion:
                contentx = chunk.choices[0].delta.content if chunk.choices and chunk.choices[0].delta.content else ""
                result += contentx

            context.append({
                "role": "assistant",
                "content": result
            })
            self.send_message(result)
        else:
            self.send_message("AUTH_FAILED")
            self.send_message("DISCONNECTING")
            self.close()

    def connected(self):
        print(f"New client connected: {self.address}")
        self.send_message("AUTH_REQUIRED")

    def handle_close(self):
        print(f"Client {self.address} disconnected")

server = WebSocketServer('127.0.0.1', 12345, AuthWebSocket)
server_thread = threading.Thread(target=server.serve_forever)
server_thread.start()

