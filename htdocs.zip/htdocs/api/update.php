<?php
//function update_col($identifier, $value) {
    $col = '';
    // $columnMap_guests = [
    //     'ne' => 'name', 'pe' => 'phone', 'ar' => 'addr',
    //     'pd' => 'pincode', 'rm' => 'room', 're' => 'rate',
    //     'be' => 'balance', 'ie' => 'indate', 'oe' => 'outdate',
    //     'ct' => 'count', 'ps' => 'pets', 'rp' => 'roomtype',
    //     'ss' => 'status', 'or' => 'offer', 'po' => 'paymethod',
    //     'rs' => 'remarks',
    // ];
    
    if (isset($identifier)) {
        $col = $identifier;
        $tble = 'guests';
    } else {
        echo json_encode(['error' => 'Invalid action']);
        die('invalid request');
    }
    
    try {
        // Assuming $rowid and $value are provided from some source
        $rowid = ''; // Replace with the correct source
        $value = $_POST['value'] ?? ''; // Replace with the correct source
        
        if (empty($rowid)) {
            echo "Error: Missing row ID";
            exit();
        }
    
        // Prepare SQL and bind parameters
        $stmt = $conn->prepare("UPDATE $tble SET $col = :value WHERE sno = :sno");
        $stmt->bindParam(':value', $value);
        $stmt->bindParam(':sno', $rowid);
        
        $stmt->execute();
        
        echo "Room updated successfully. Updated ID: " . $rowid;
    
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

?>