<?php
function getrooms($jdata) {
      
    global $conn;
    $sql = "SELECT room FROM room WHERE ";
    $params = [];
    $conditions = [];

        if (!empty($jdata['floor'])) {
            $conditions[] = "floor = :floor";
            $params[':floor'] = $jdata['floor'];
        } 
        if (!empty($jdata['type'])) {
            $conditions[] = "type = :type";
            $params[':type'] = $jdata['type'];
        }
        if (!empty($jdata['status'])) {
            $conditions[] = "status = :status";
            $params[':status'] = $jdata['status'];
        }


    if (empty($conditions)) {
        echo json_encode(['error' => 'No valid search criteria provided']);
        return;
    }

    $sql .= implode(" AND ", $conditions);

    try {
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            echo json_encode($result);
        } else {
            echo 'No record found. Try other parameters.';
        }
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
}

getrooms($jdata);
// echo json_encode($guestInfo);
?>
