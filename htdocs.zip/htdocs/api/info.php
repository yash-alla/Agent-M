<?php
function getinfo($jdata) {
      // Assuming you have a PDO connection established
global $conn;
    $sql = "SELECT * FROM guest WHERE ";
    $params = [];
    $conditions = [];

    if (!empty($jdata['sno'])) {
        $conditions[] = "sno = :sno";
        $params[':sno'] = $jdata['sno'];
    } else {
        if (!empty($jdata['name'])) {
            $conditions[] = "name = :name";
            $params[':name'] = $jdata['name'];
        }
        if (!empty($jdata['status'])) {
            $conditions[] = "status = :status";
            $params[':status'] = $jdata['status'];
        }
        if (!empty($jdata['check_in_date'])) {
            $conditions[] = "indate = :indate";
            $params[':indate'] = $jdata['check_in_date'];
        }
        if (!empty($jdata['check_out_date'])) {
            $conditions[] = "outdate = :outdate";
            $params[':outdate'] = $jdata['check_out_date'];
        }
    }

    if (empty($conditions)) {
        echo json_encode(['error' => 'No valid search criteria provided']);
        return;
    }

    $sql .= implode(" AND ", $conditions);

    try {


       
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            echo json_encode($result);
        } else {
            echo 'No record found. Try other parameters.';
        }
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
}

// Assuming $jdata is already defined and contains the JSON input
getinfo($jdata);

// Remove this line as we're now echoing directly in the function
// echo json_encode($guestInfo);
?>
