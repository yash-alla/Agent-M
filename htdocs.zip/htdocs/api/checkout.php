<?php
function checkout($pdo, $roomNumber) {
    try {
        // Start transaction
        $pdo->beginTransaction();

        // Get the last guest for the given room number
        $stmt = $pdo->prepare("
            SELECT sno, balance 
            FROM guest 
            WHERE room = :room_number 
            ORDER BY sno DESC 
            LIMIT 1
        ");
        $stmt->execute([':room_number' => $roomNumber]);
        $lastGuest = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$lastGuest) {
            throw new Exception("No guest found for room number: " . $roomNumber);
        }

        // Check if balance is 0
        if ($lastGuest['balance'] == 0) {
            // Update the status to 'checkedout' for the last guest
            $updateStmt = $pdo->prepare("
                UPDATE guest 
                SET status = 'checkedout' 
                WHERE sno = :sno
            ");
            $updateStmt->execute([':sno' => $lastGuest['sno']]);

            // Commit transaction
            $pdo->commit();

            // Fetch the updated row
            $stmt = $pdo->prepare("
                SELECT * 
                FROM guest 
                WHERE sno = :sno
            ");
            $stmt->execute([':sno' => $lastGuest['sno']]);
            $updatedGuest = $stmt->fetch(PDO::FETCH_ASSOC);

            // Return success message and updated guest info
            echo json_encode([
                'message' => 'Guest checked out successfully',
                'guest' => $updatedGuest
            ]);
        } else {
            // If balance is not 0, return a message
            echo json_encode([
                'message' => 'Cannot checkout. Guest has an outstanding balance check info of room and try payment with balance again.',
                'balance' => $lastGuest['balance']
            ]);
        }

    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        echo json_encode(['error' => $e->getMessage()]);
    }
}

// Database connection


// Get the room number from the request

if ($jdata['room_number'] === null) {
    echo json_encode(['error' => 'Room number is null']);
    exit;
}

// Call the function
checkout($conn, $jdata['room_number']);
?>
