<?php
session_start();
$jdata;
$conn;
function clean($data) {
    return preg_replace('/[^a-zA-Z0-9#\/-]/', '', $data);
}

function connectToDatabase($servername, $dbname, $username, $password) {
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        echo json_encode(['error' => 'Database connection error: ' . $e->getMessage()]);
        exit();
    }
}

if (!isset($_GET['h'])) {
    echo json_encode(['error' => 'Action not set']);
    exit();
}

$action = $_GET['h'];

// $servername = DB_SERVERNAME;
// $dbname = DB_NAME;
// $username = DB_USERNAME;
// $password = DB_PASSWORD;

function jd(){
    global $jdata;
    $jdata = json_decode(file_get_contents('php://input'), true);
    
    if ($jdata === null && json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['error' => 'Invalid JSON payload']);
        exit();
    }
}

switch ($action) {
    case 'info':
        jd();
        include 'cred.php';
        $conn = connectToDatabase($servername, $dbname, $username, $password);
        include 'info.php';
        $conn = null;
        break;
    case 'payment':
        jd();
        include 'cred.php';
        $conn = connectToDatabase($servername, $dbname, $username, $password);
        include 'payment.php';
        break;
    case 'update':
        if (!isset($_GET['c'], $_GET['v'])) {
            echo json_encode(['error' => 'Missing parameters']);
            exit();
        }
        $identifier = clean($_GET['c']);
        $value = clean($_GET['v']);
        include 'cred.php';
        $conn = connectToDatabase($servername, $dbname, $username, $password);
        require 'update.php';
        break;
    case 'checkin':
        include 'allot.php';
        break;
    case 'checkout':
        jd();
        include 'cred.php';
        $conn = connectToDatabase($servername, $dbname, $username, $password);
        include 'checkout.php';
        break;
    case 'room':
        jd();
        include 'cred.php';
        $conn = connectToDatabase($servername, $dbname, $username, $password);
        include 'getroom.php';
        $conn = null;
        break;    
    default:
        echo json_encode(['error' => 'Invalid action']);
        exit();
}

$conn = null;
?>
