<?php
include_once('cred.php');

$json = file_get_contents('php://input');
$data = json_decode($json, true);

if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['error' => 'Invalid JSON payload']);
    exit();
}

if(empty($data['room'])){
    echo json_encode(['error' => 'Check for rooms (Example 6) and send again']);
    exit();
}

if(istoday($data['check_in_date'])){
    $status = 'checkin';
} else {
    $status = 'reserved';
}

create_room(
    $data['room'], $data['guest_name'], $data['phone_number'], ' ', ' ', 
    $data['check_in_date'], $data['check_out_date'], $data['number_of_people'], 
    $data['pets'], $data['room_type'], $status, $data['paymethod']
);

function create_room($room, $name, $phone, $addr, $rate, $indate, $outdate, $count, $pets, $roomtype, $status, $paymethod) {
    global $servername, $dbname, $username, $password;

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $sql = "INSERT INTO guest (room, name, phone, addr, rate, indate, outdate, count, pets, roomtype, status, paymethod)
                VALUES (:room, :name, :phone, :addr, :rate, :indate, :outdate, :count, :pets, :roomtype, :status, :paymethod)";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':room' => $room,
            ':name' => $name,
            ':phone' => $phone,
            ':addr' => $addr,
            ':rate' => $rate ?: null,
            ':indate' => $indate,
            ':outdate' => $outdate,
            ':count' => $count ?: 0,
            ':pets' => $pets ?: 0,
            ':roomtype' => $roomtype,
            ':status' => $status,
            ':paymethod' => $paymethod
        ]);
        
        $rowid = $conn->lastInsertId();
        $_SESSION['dbid'] = $rowid;

        // Prepare data for updateroomstatus.php
        $GLOBALS['jdata'] = [
            'room' => $room,
            'status' => 0
        ];
        
        
        // Include updateroomstatus.php to update room status
        include_once('updateroomstatus.php');
        die("New room $status successful. just say Have a good day!");
        
    } catch(PDOException $e) {
        echo json_encode(['error' => $e->getMessage()]);
    } finally {
        $conn = null;
    }
}

function istoday($date){
    date_default_timezone_set('America/New_York');
    $today = date('m-d-Y');
    return $date === $today;
}

?>
