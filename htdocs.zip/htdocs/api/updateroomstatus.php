<?php
function statusupdate($stat, $room) {
    global $servername, $dbname, $username, $password;
    
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $sql = "UPDATE room SET status = :stat WHERE room = :room";
        
        $stmt = $conn->prepare($sql);
        
        // Bind parameters
        $stmt->bindParam(':stat', $stat, PDO::PARAM_INT);
        $stmt->bindParam(':room', $room, PDO::PARAM_STR);
        
        // Execute the statement
        $result = $stmt->execute();

        if ($result) {
            $rowCount = $stmt->rowCount();
            if ($rowCount > 0) {
                error_log("Room status updated successfully. Rows affected: $rowCount");
            } else {
                error_log("No rows updated. Room might not exist.");
            }
        } else {
            error_log("Failed to update status.");
        }
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
    } finally {
        $conn = null;
    }
}

// Use the global $jdata set in the main file
global $jdata;

// Check if $jdata is set and contains the required information
if (isset($jdata['room']) && isset($jdata['status'])) {
    statusupdate($jdata['status'], $jdata['room']);
} else {
    error_log("Missing room or status information for status update.");
}
?>
