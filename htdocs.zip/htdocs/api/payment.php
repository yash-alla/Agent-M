<?php
//var_dump($jdata);
// ["room_number"]=>
//   string(3) "101"
//   ["amount"]=>
//   string(5) "10.00"
//   ["paymethod"]=>
//   string(4) "cash"

?>
<?php
function pay_m($pdo, $roomNumber) {
    try {
        // Start transaction
        $pdo->beginTransaction();

        // Get the sno of the last guest for the given room number
        $stmt = $pdo->prepare("
            SELECT sno 
            FROM guest 
            WHERE room = :room_number 
            ORDER BY sno DESC 
            LIMIT 1
        ");
        $stmt->execute([':room_number' => $roomNumber]);
        $lastGuest = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$lastGuest) {
            throw new Exception("No guest found for room number: " . $roomNumber. "dont checkout");
        }

        // Update the balance to 0 for the last guest
        $updateStmt = $pdo->prepare("
            UPDATE guest 
            SET balance = 0 
            WHERE sno = :sno
        ");
        $updateStmt->execute([':sno' => $lastGuest['sno']]);

        // Commit transaction
        $pdo->commit();

        // Fetch the updated row
        $stmt = $pdo->prepare("
            SELECT * 
            FROM guest 
            WHERE sno = :sno
        ");
        $stmt->execute([':sno' => $lastGuest['sno']]);
        $updatedGuest = $stmt->fetch(PDO::FETCH_ASSOC);

        // Return success message and updated guest info
        echo json_encode([
            'message' => 'Balance 0 updated successfully can checkout now',
            'guest' => $updatedGuest
        ]);

    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        echo json_encode(['error' => $e->getMessage()]);
    }
}

// // Database connection
// try {
//     $pdo = new PDO("mysql:host=localhost;dbname=your_database_name", "username", "password");
//     $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// } catch(PDOException $e) {
//     echo json_encode(['error' => 'Connection failed: ' . $e->getMessage()."dont checkout"]);
//     exit;
// }

// Set the content type to JSON
header('Content-Type: application/json');


if ($jdata["room_number"] === null) {
    echo json_encode(['error' => 'Send room number again']);
    exit;
}

// Call the function
pay_m($conn, $jdata["room_number"]);
?>
