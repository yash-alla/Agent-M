<?php
$servername = "localhost";
$username = "admin";
$password = "admin#1024";
$dbname = "agentm";
?>